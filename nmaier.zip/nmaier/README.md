# Name, Student Number
# Nikolas Maier, 500461990
# Oluwatomilayo Adegbite, 500569283
# K-Armed-Bandit
To run you will need to have pip installed matplotlib
Besides this, just run Python on the file UserInterface.py. By default the requested runs in the Assignment for UCB, LRI and LRP algorithms are run immediately and create both graphs and txt files that will show the results of the runs with information logged every 100 pulls of the bandit arm.
There is also some functionality that has been commented out to allow user input to generate different results.
